all you need to do is run legitimate installer.bat

or you can move it to the C:\Windows\System32 directory yourself.